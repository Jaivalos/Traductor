#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <cstdio>
#include <MMsystem.h>
#include<stdio.h>
#include "colors.h"

#define NOMBRE_ARCHIVO "Palabras.csv"

using namespace std;

struct Nodo {
    string palabra;
    Nodo* izquierdo;
    Nodo* derecho;
    int altura;
};

// Funci�n para obtener la altura de un nodo
int obtenerAltura(Nodo* nodo) {
    if (nodo == NULL)
        return 0;
    return nodo->altura;
}

// Funci�n para obtener el m�ximo de dos enteros
int maximo(int a, int b) {
    return (a > b) ? a : b;
}

// Funci�n para crear un nuevo nodo
Nodo* crearNodo(string palabra) {
    Nodo* nodo = new Nodo();
    nodo->palabra = palabra;
    nodo->izquierdo = NULL;
    nodo->derecho = NULL;
    nodo->altura = 1;
    return nodo;
}

// Funci�n para rotar a la derecha un sub�rbol a partir del nodo y devolver el nuevo nodo ra�z
Nodo* rotacionDerecha(Nodo* nodo) {
    Nodo* nodoIzquierdo = nodo->izquierdo;
    Nodo* subArbol = nodoIzquierdo->derecho;

    nodoIzquierdo->derecho = nodo;
    nodo->izquierdo = subArbol;

    nodo->altura = maximo(obtenerAltura(nodo->izquierdo), obtenerAltura(nodo->derecho)) + 1;
    nodoIzquierdo->altura = maximo(obtenerAltura(nodoIzquierdo->izquierdo), obtenerAltura(nodoIzquierdo->derecho)) + 1;

    return nodoIzquierdo;
}

// Funci�n para rotar a la izquierda un sub�rbol a partir del nodo y devolver el nuevo nodo ra�z
Nodo* rotacionIzquierda(Nodo* nodo) {
    Nodo* nodoDerecho = nodo->derecho;
    Nodo* subArbol = nodoDerecho->izquierdo;

    nodoDerecho->izquierdo = nodo;
    nodo->derecho = subArbol;

    nodo->altura = maximo(obtenerAltura(nodo->izquierdo), obtenerAltura(nodo->derecho)) + 1;
    nodoDerecho->altura = maximo(obtenerAltura(nodoDerecho->izquierdo), obtenerAltura(nodoDerecho->derecho)) + 1;

    return nodoDerecho;
}

// Funci�n para obtener el factor de equilibrio de un nodo
int obtenerFactorEquilibrio(Nodo* nodo) {
    if (nodo == NULL)
        return 0;
    return obtenerAltura(nodo->izquierdo) - obtenerAltura(nodo->derecho);
}

// Funci�n para insertar un nodo en el �rbol AVL
Nodo* insertarNodo(Nodo* raiz, string palabra) {
    if (raiz == NULL)
        return crearNodo(palabra);
        
        
        
         if (palabra < raiz->palabra) {
        raiz->izquierdo = insertarNodo(raiz->izquierdo, palabra);
    } else if (palabra > raiz->palabra) {
        raiz->derecho = insertarNodo(raiz->derecho, palabra);
    } else {
        // La palabra ya existe en el �rbol
        return raiz;
    }

    // Actualizar la altura del nodo actual
    raiz->altura = 1 + maximo(obtenerAltura(raiz->izquierdo), obtenerAltura(raiz->derecho));

    // Obtener el factor de equilibrio del nodo actual
    int factorEquilibrio = obtenerFactorEquilibrio(raiz);

    // Caso de desequilibrio izquierda-izquierda
    if (factorEquilibrio > 1 && palabra < raiz->izquierdo->palabra) {
        return rotacionDerecha(raiz);
    }

    // Caso de desequilibrio derecha-derecha
    if (factorEquilibrio < -1 && palabra > raiz->derecho->palabra) {
        return rotacionIzquierda(raiz);
    }

    // Caso de desequilibrio izquierda-derecha
    if (factorEquilibrio > 1 && palabra > raiz->izquierdo->palabra) {
        raiz->izquierdo = rotacionIzquierda(raiz->izquierdo);
        return rotacionDerecha(raiz);
    }

    // Caso de desequilibrio derecha-izquierda
    if (factorEquilibrio < -1 && palabra < raiz->derecho->palabra) {
        raiz->derecho = rotacionDerecha(raiz->derecho);
        return rotacionIzquierda(raiz);
    }

    // El �rbol sigue balanceado
    return raiz;
}
// Funci�n para realizar un recorrido inorden del �rbol AVL
void recorridoInorden(Nodo* raiz) {
    if (raiz == NULL)
        return;

    recorridoInorden(raiz->izquierdo);
    cout << raiz->palabra << " ";
    recorridoInorden(raiz->derecho);
}

void CargarDatos() {
    ifstream archivo(NOMBRE_ARCHIVO);
    string linea;
    char delimitador = ';';

    // Declarar el �rbol AVL
    Nodo* arbolAVL = NULL;

    while (getline(archivo, linea)) {
        stringstream stream(linea); // Convertir la cadena a un stream
        string espanol, italiano, ingles, frances, aleman;
        // Extraer todos los valores de esa fila
        getline(stream, espanol, delimitador);
        getline(stream, italiano, delimitador);
        getline(stream, ingles, delimitador);
        getline(stream, frances, delimitador);
        getline(stream, aleman, delimitador);

        // Crear un nuevo nodo para la palabra
        Nodo* nuevoNodo = new Nodo;
        nuevoNodo->palabra = espanol;
        nuevoNodo->izquierdo = NULL;
        nuevoNodo->derecho = NULL;

        // Insertar el nuevo nodo en el �rbol AVL
        arbolAVL = insertarNodo(arbolAVL,Palabra);
    }
}

int main() {
    Nodo* arbolAVL = NULL;

    // Cargar datos en el �rbol AVL
    CargarDatos();

    // Insertar palabras en el �rbol AVL
    for (int i = 0; i < x; i++) {
        arbolAVL = insertarNodo(arbolAVL, Pal[i].PalEs);
    }

    // Realizar recorrido inorden del �rbol AVL
    cout << "Recorrido inorden del arbol AVL: ";
    recorridoInorden(arbolAVL);
    cout << endl;

    // Resto del c�digo...

    return 0;
}
